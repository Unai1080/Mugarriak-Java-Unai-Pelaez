package Controller;

public interface IPictureViewer {
    public void award();
    public void remove();


}
